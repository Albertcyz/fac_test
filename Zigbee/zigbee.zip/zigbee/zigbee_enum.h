﻿#ifndef __ZIGBEE_ENUM_H__
#define __ZIGBEE_ENUM_H__

#include <string>
typedef enum device_model
{
	LUMI_GATEWAY = 0,
	LUMI_SENSOR_SWITCH = 1,
	LUMI_SENSOR_MOTION = 2,
	LUMI_SENSOR_MAGNET = 3,
	LUMI_ZIGBEE_COMMON_CONTROLLER = 4,
	LUTUO_ENOCEAN_CONTROLLER = 5,

	YEE_LIGHT_RGB = 6,

	LUMI_CTRL_NEUTRAL_2 = 7,
	LUMI_SENSOR_CUBE = 8,
	LUMI_CTRL_NEUTRAL_1 = 9,
	LUMI_SENSOR_HT = 10,
	LUMI_PLUG = 11,
	
	LUMI_SENSOR_86SWITCH2 = 12,
	//LUMI_CTRL_CURTAIN = 13,
	LUMI_CURTAIN = 13,
	LUMI_SENSOR_86SWITCH1 = 14,
	//LUMI_CURTAIN = 15,
	LUMI_86PLUG = 17,
	
	LUMI_SENSOR_NATGAS = 18,
	LUMI_SENSOR_WEATHER = 19,
	LUMI_AQ_CTRL_LN1 = 20,
	LUMI_AQ_CTRL_LN2 = 21,
	//GE_DIMMABLE_LIGHTING = 32,
	//=====model >= 25 model no need join version
	
	LUMI_PLUG_ES = 25,
	LUMI_WEATHER_ES = 26,
	LUMI_SWITCH_ES = 27,
	LUMI_MOTION_ES = 28,
	LUMI_MAGNET_ES = 29,
	LUMI_LN2_ES = 30,
	LUMI_CUBE_ES = 31,
	GE_DIMMABLE_LIGHTING = 32,
	LUMI_HT_ES = 33,

	LUMI_PLUG_AQ = 50,
	LUMI_SWITCH_AQ = 51,
	LUMI_MOTION_AQ = 52,
	LUMI_MAGNET_AQ = 53,
	//======================================================================
	LUMI_SENSOR_IR = 41,
	LUMI_LIGHT_RGBW = 42,
	LUMI_UNKNOW = 0xFFFFFFF,
}device_model_e;



#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
} /* end of the 'extern "C"' block */
#endif
#endif
