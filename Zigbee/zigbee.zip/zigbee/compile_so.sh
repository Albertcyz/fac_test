$CXX -fPIC -shared -o libzigbee.so *.cpp *.c  -std=c++11 -D __linux__

